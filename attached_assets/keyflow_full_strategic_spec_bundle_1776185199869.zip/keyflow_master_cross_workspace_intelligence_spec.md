# KeyFlow Master Cross-Workspace Intelligence Architecture Spec
## AI Coder Implementation Document

### Objective
Define the shared intelligence architecture that connects **Clients, Calendar, Revenue, Content, Flows, and Projects** into one coherent operating system.

This document is not a single-page redesign spec. It is the **system-level architecture spec** that ensures every workspace draws from the full context of the app, supports richer AI interaction, and behaves as part of one business operating environment rather than as isolated modules.

This spec also includes the required **deepening of the Projects workspace** so Projects becomes a meaningful delivery execution module rather than a lightweight board utility.

Do not remove any existing major module. Re-architect the system so each module remains specialized but is fed by shared business context and cross-module intelligence.

---

## 1. Core Product Principle

KeyFlow should not consist of “smart pages.”
It should consist of:

> **specialized workspaces powered by one shared business context layer**

That means every module should:
- show its own operational truth
- draw intelligence from the rest of the app
- support recommendations and AI actions based on broader system state
- contribute events back into the system

This is the foundation for making AI genuinely useful.

---

## 2. The Shared Business Context Layer

Create a conceptual system layer that all modules can read from and write to.

### Purpose
The Business Context Layer should know:
- who the client is
- what they bought
- what they booked
- what they owe
- what content they saw
- what segment they belong to
- which forms they submitted
- which project they are in
- which automations ran
- what risks and opportunities exist
- what changed recently

### This layer should connect:
- entities
- events
- states
- relationships
- automation outcomes
- recommendations

### All workspaces should query this layer differently.

---

## 3. Workspaces in the Final System

The app should ultimately behave as:

- **Clients** = relationship workspace
- **Calendar** = schedule workspace
- **Revenue** = quote-to-cash workspace
- **Content** = audience/content workspace
- **Flows** = orchestration and intelligence workspace
- **Projects** = delivery execution workspace

Each workspace remains distinct.
But none should feel isolated.

---

## 4. Cross-Workspace Intelligence Rule

Every workspace must support two layers:

### Layer 1 — Operational Truth
The raw state of the module.

Examples:
- invoice overdue
- booking scheduled
- segment size = 20
- project status = In Progress
- automation active

### Layer 2 — Cross-App Intelligence
What the rest of the system implies about that state.

Examples:
- invoice overdue and client has booking tomorrow
- booking canceled twice and VIP client
- disengaged segment has no nurture campaign
- project milestone overdue and invoice not yet generated
- accepted quote but project not created
- form submissions rising but no welcome flow enabled

This rule should guide the design and logic of every module.

---

## 5. Core Shared Entities

All major modules should be designed around shared entities and relationships.

### Required shared entities
- Client / Contact
- Booking
- Service / Product / Package
- Quote
- Invoice
- Payment
- Campaign
- Post
- Segment
- Form
- Project
- Task / Milestone
- Flow / Automation
- Staff / Owner

### Required relationship examples
- Client has Bookings
- Client has Quotes / Invoices / Payments
- Client belongs to Segment(s)
- Client submits Form(s)
- Client participates in Campaign(s)
- Client is linked to Project(s)
- Project is linked to Service/Package
- Project is linked to Quote / Invoice
- Flow touches one or more modules
- Booking may link to Payment / Review / Follow-up
- Content may target Segment(s)
- Form may feed Segment or Campaign or Flow

This shared relationship model is essential for intelligent behavior.

---

## 6. Shared Event Layer

The system should maintain a unified event model across modules.

### Example event families
- client.created
- client.stage_changed
- client.inactive
- booking.created
- booking.completed
- booking.cancelled
- quote.sent
- quote.viewed
- quote.accepted
- invoice.sent
- invoice.overdue
- payment.received
- campaign.sent
- campaign.opened
- post.scheduled
- post.published
- form.submitted
- segment.changed
- project.created
- project.stage_changed
- milestone.completed
- project.blocked
- flow.failed
- flow.succeeded

### Why this matters
- Flows can use them
- Activity/timeline systems can use them
- AI recommendations can reason from them
- every module becomes more explainable and traceable

---

## 7. Shared Recommendation Engine

Each workspace should be able to show recommendations based on both local state and global state.

### Required recommendation types
- missing automation
- overdue intervention
- underused channel
- at-risk client
- underbooked time slot
- stalled quote
- collectible invoice
- untargeted segment
- project blocked
- project invoice milestone ready
- missing follow-up
- missing review request
- missing campaign for valuable audience

### Recommendation cards should generally include:
- what is happening
- why it matters
- modules involved
- confidence or severity
- action CTA

This should not be limited to Flows. It should exist everywhere.

---

## 8. AI Interaction Model

AI should not exist as a decorative badge or a separate novelty surface.
It should be embedded into each module using shared context.

### AI must be able to:
- read cross-module state
- summarize what matters now
- recommend next actions
- generate content/messages/workflows
- explain why it made a suggestion
- identify missing setup or coverage
- detect risk and opportunity

### AI output should be contextual
Not generic prompts.

Example:
- “This VIP client has not booked in 45 days, has an unpaid invoice, and no re-engagement flow is active. Recommend outreach + payment follow-up.”
- “Wednesday has low booking density and a campaign slot is free. Recommend scheduling a promotion for the top underbooked service.”
- “Accepted quote exists but no project has been created. Recommend starting project template ‘Client Delivery Setup’.”

This is the standard.

---

## 9. Clients Workspace in the Shared Model

Clients should draw from:
- bookings
- revenue
- campaigns
- forms
- segments
- projects
- flows
- recent system events

### Clients should surface:
- relationship health
- revenue context
- booking context
- campaign engagement
- form origin
- project delivery status
- automation coverage
- recommended next action

### Examples
- client has overdue invoice and upcoming booking
- client is VIP but no nurture campaign exists
- client project is blocked and no follow-up sent
- client submitted form but no onboarding flow active

Clients becomes the relationship intelligence workspace.

---

## 10. Calendar Workspace in the Shared Model

Calendar should draw from:
- clients
- services/packages
- payments
- revenue
- content/promotions
- projects
- staff
- flows

### Calendar should surface:
- booking value
- payment status
- client risk/value
- project deadlines near bookings
- underbooked slots
- promotion opportunities
- reminder automation coverage
- rebooking recommendations

### Examples
- booking tomorrow, payment pending, no reminder sent
- underbooked Tuesday and campaign slot available
- project delivery due near scheduled onboarding session

Calendar becomes the schedule intelligence workspace.

---

## 11. Revenue Workspace in the Shared Model

Revenue should draw from:
- clients
- services/packages
- bookings
- projects
- flows
- campaign attribution if available

### Revenue should surface:
- collectible now
- overdue risk
- quote follow-up opportunities
- project milestones tied to billing
- payment behavior by client
- automation coverage for collections
- linked service/package context

### Examples
- quote accepted but no project created
- milestone complete and invoice not sent
- client overdue but booking tomorrow
- recurring opportunity based on repeated purchases

Revenue becomes the quote-to-cash intelligence workspace.

---

## 12. Content Workspace in the Shared Model

Content should draw from:
- clients
- segments
- forms
- bookings
- offers/packages
- flows
- revenue goals

### Content should surface:
- which audiences need content
- what offers need promotion
- content gaps
- under-contacted segments
- nurture opportunities
- re-engagement opportunities
- suggested content based on bookings or inactivity

### Examples
- disengaged audience but no re-engagement campaign
- underbooked service should be promoted
- form submissions rising but no nurture content active
- accepted package should trigger onboarding content

Content becomes the audience-aware content engine.

---

## 13. Flows Workspace in the Shared Model

Flows should draw from **everything** and become the orchestration surface.

### Flows should surface:
- which modules are automated
- which modules are under-automated
- what flows are recommended
- what failed
- what impacted which records
- what business problems each flow solves

### Required behavior
- cross-module triggers
- cross-module conditions
- cross-module actions
- cross-module recommendations
- coverage map
- execution diagnostics
- module-aware template recommendations

Flows becomes the orchestration and intelligence workspace.

---

## 14. Projects Workspace Must Be Deepened

This is a required upgrade.

Projects must stop being just:
- quick project creation
- simple board
- template + status columns

Projects should become:

> **the delivery execution workspace of the business**

This is the correct role for Projects inside KeyFlow.

---

## 15. What Projects Should Manage

Projects should represent delivery / fulfillment / implementation work tied to business activity.

### Projects should answer:
- what are we delivering?
- for which client?
- from which accepted quote/package?
- what stage is the work in?
- what milestones remain?
- what is blocked?
- what revenue is linked?
- what automations are supporting delivery?
- what is due next?

This makes Projects valuable and distinct.

---

## 16. Projects Must Draw From the Whole App

Projects should draw from:
- Clients
- Revenue (quotes, invoices, payments)
- Calendar / bookings
- Content (deliverables if relevant)
- Flows / automation coverage
- staff / ownership
- activity/timeline events

### Examples
- project created from accepted quote
- project linked to service package
- project milestone triggers invoice
- project blocked because client has not responded
- project has onboarding booking scheduled
- project completion triggers review flow
- project related campaign assets still pending

This is crucial.

---

## 17. Deepened Projects Workspace Model

Projects should include:

### A. Top execution summary
- Active
- Due soon
- Blocked
- Waiting on client
- Completed recently
- Unassigned

### B. Project board / stage view
Recommended stages:
- Not Started
- In Progress
- Waiting on Client
- Review
- Completed
- Blocked

This is stronger than generic Active / In Progress / Completed / On Hold.

### C. Rich project cards
Each project card should show:
- project name
- client
- due date
- stage
- completion %
- task count remaining
- owner
- linked package/service
- risk/block warning
- linked invoice/quote state if useful

### D. Project detail workspace
Every project should open into a deeper workspace with:
- Overview
- Tasks
- Milestones
- Timeline
- Notes
- Client
- Revenue
- Calendar
- Flows / automation coverage
- Deliverables

### E. Templates
Templates should support:
- phases
- default tasks
- milestone offsets
- owners/roles
- linked deliverables
- linked automation hooks
- package/service associations

This is what makes Projects first-class.

---

## 18. Project + Flow Relationship

Do not fully merge Projects into Flows.

### Correct model
- **Projects** = what humans are delivering
- **Flows** = how the system reacts and assists around delivery

### Examples
#### project.created
Flow:
- assign template tasks
- notify owner
- send client welcome
- schedule kickoff booking

#### milestone.completed
Flow:
- notify client
- generate invoice
- create next-stage tasks

#### project.blocked
Flow:
- notify owner
- create escalation task
- send client reminder

#### waiting_on_client for 5 days
Flow:
- send follow-up
- pause dependent internal steps
- flag in project board

This relationship is the right one.

---

## 19. Shared AI Behavior by Module

Each module should expose AI in a way that uses shared context.

### Clients
AI suggests follow-up based on revenue, bookings, project status, engagement.

### Calendar
AI suggests schedule optimization and promotions based on bookings, services, audience, revenue.

### Revenue
AI suggests collections, quote follow-up, milestone billing, recurring opportunities.

### Content
AI suggests what to publish, to whom, and when based on segments, bookings, offers, and behavior.

### Flows
AI suggests missing automations, diagnostics, and orchestration opportunities across the whole app.

### Projects
AI suggests milestone actions, delivery risk, next tasks, client communications, and automation opportunities.

This is how AI becomes truly useful.

---

## 20. Shared UI Rules Across All Workspaces

### Rule 1
Every workspace must show both local truth and cross-module implications.

### Rule 2
Every major entity should have links to related entities.

### Rule 3
Recommendations should include:
- why
- modules involved
- next step

### Rule 4
AI should act in-context, not as a disconnected utility.

### Rule 5
Flows should be visible as supporting automation across all relevant modules.

### Rule 6
Projects, once deepened, should be clearly integrated into the rest of the OS.

---

## 21. System-Level Components to Add

### A. Business Context Layer
A shared context service/model that provides:
- linked records
- risk flags
- opportunities
- recent events
- automation coverage
- recommendations

### B. Unified Event Layer
Shared business events used for:
- timelines
- flows
- diagnostics
- AI reasoning

### C. Recommendation Engine
Shared recommendation system for all workspaces.

### D. Automation Coverage Engine
Tracks which modules and business problems are automated.

### E. Relationship Graph / Entity Link Layer
Lets modules show:
- related clients
- related invoices
- related bookings
- related projects
- related campaigns
- related flows

---

## 22. Suggested Final High-Level Component Tree

```text
KeyFlowApp
  BusinessContextLayer
  EventLayer
  RecommendationEngine
  AutomationCoverageEngine
  EntityRelationshipLayer

  ClientsWorkspace
  CalendarWorkspace
  RevenueWorkspace
  ContentWorkspace
  FlowsWorkspace
  ProjectsWorkspace
```

### ProjectsWorkspace
```text
ProjectsWorkspace
  ProjectExecutionSummary
  ProjectBoard
  ProjectCard[]
  ProjectTemplates
  ProjectDetailWorkspace
    Overview
    Tasks
    Milestones
    Timeline
    Notes
    Client
    Revenue
    Calendar
    FlowCoverage
    Deliverables
```

### FlowsWorkspace
```text
FlowsWorkspace
  FlowHealthStrip
  AutomationCoverageMap
  RecommendedFlows
  MyFlows
  Templates
  ActivityLog
```

---

## 23. Prioritized Implementation Plan

### Phase 1 — Shared intelligence foundation
1. Define Business Context Layer
2. Define shared event model
3. Define cross-module entity relationships
4. Define recommendation engine inputs/outputs

### Phase 2 — Make Flows the orchestration brain
5. Add coverage map
6. Add recommended flows based on app-wide state
7. Add cross-module triggers/conditions/actions
8. Add module-aware diagnostics

### Phase 3 — Deepen Projects
9. Redefine Projects as delivery execution workspace
10. Redesign project board and project cards
11. Add project detail workspace
12. Add richer templates
13. Add project links to clients/revenue/calendar/flows

### Phase 4 — Cross-module upgrades
14. Update Clients to read revenue/bookings/projects/flows
15. Update Calendar to read clients/revenue/content/projects/flows
16. Update Revenue to read clients/projects/bookings/flows
17. Update Content to read segments/forms/bookings/revenue/flows
18. Update Projects to read all relevant modules

### Phase 5 — AI and recommendations
19. Add contextual AI recommendations to every workspace
20. Standardize recommendation card format
21. Add explainability for major AI suggestions

---

## 24. Acceptance Criteria

The system-level overhaul is successful if:

1. Every major workspace draws useful context from the rest of the app
2. Flows visibly orchestrates behavior across all modules
3. Projects has been deepened into a real delivery execution workspace
4. AI recommendations in each workspace use cross-app context
5. Entity relationships are visible and useful
6. Users can move between related records naturally
7. Recommendations and automations feel like part of one system
8. No major module feels isolated
9. No current major module is removed unnecessarily

---

## 25. Non-Negotiables

- Do not leave modules isolated
- Do not keep Projects as a shallow board if it remains top-level
- Do not make Flows blind to the rest of the app
- Do not treat AI as mostly cosmetic
- Do not remove specialization from modules
- Do not merge Projects fully into Flows unless Projects remains intentionally lightweight and non-strategic

---

## 26. Target Outcome Statement

The final KeyFlow system should feel like:

> one intelligent business operating system where each workspace is specialized, every module draws from shared business context, Flows orchestrates behavior across the whole app, and Projects functions as a deep delivery execution workspace tied to clients, revenue, calendar, content, and automation.
